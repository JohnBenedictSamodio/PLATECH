import os
import time
import multiprocessing as mp

import psutil
import matplotlib.pyplot as plt


#1
def cpu_bound_workload(task_id: int, target_core: int = None) -> float:
    """Run a CPU-heavy workload and optionally bind this process to a CPU core."""
    if target_core is not None:
        try:
            process = psutil.Process()
            process.cpu_affinity([target_core])
        except (AttributeError, psutil.Error, OSError):
            
            # Linux fallback. Other platforms may not support CPU affinity.
            try:
                os.sched_setaffinity(0, {target_core})
            except (AttributeError, OSError):
                pass

    try:
        actual_affinity = psutil.Process().cpu_affinity()
    except (AttributeError, psutil.Error, OSError):
        actual_affinity = "not available"

    pid = os.getpid()
    print(
        f"[Task {task_id}] PID: {pid} | "
        f"Bound Core: {target_core} | Active Mask: {actual_affinity}",
        flush=True,
    )

    # CPU-heavy arithmetic loop (finding prime numbers).
    start_time = time.perf_counter()
    count = 0

    for num in range(2, 300000):
        is_prime = True
        limit = int(num ** 0.5)
        for divisor in range(2, limit + 1):
            if num % divisor == 0:
                is_prime = False
                break
        if is_prime:
            count += 1

    elapsed_time = time.perf_counter() - start_time
    print(
        f"[Task {task_id}] Completed in {elapsed_time:.3f} s "
        f"(Found {count} primes).",
        flush=True,
    )
    return elapsed_time


#2
def run_single_core_contention(num_tasks: int = 4) -> float:
    """Run all worker processes pinned to CPU Core 0."""
    print("\n" + "=" * 65)
    print(
        f"SCENARIO 1: Running {num_tasks} Processes "
        "Pinned to Core 0 (Contention)"
    )
    print("=" * 65)

    start_total = time.perf_counter()
    processes = []

    for task_id in range(num_tasks):
        process = mp.Process(
            target=cpu_bound_workload,
            args=(task_id, 0),
        )
        processes.append(process)
        process.start()

    for process in processes:
        process.join()

    total_time = time.perf_counter() - start_total
    print(
        f"--> Total Elapsed Time (Single-Core Contention): "
        f"{total_time:.3f}s"
    )
    return total_time


#3
def run_multi_core_parallel(num_tasks: int = 4) -> float:
    """Run workers distributed across available CPU cores."""
    available_cores = psutil.cpu_count(logical=True) or os.cpu_count() or 1
    allowed_cores = None

    # Respect the CPU cores available to this process when supported.
    try:
        allowed_cores = sorted(psutil.Process().cpu_affinity())
    except (AttributeError, psutil.Error, OSError):
        pass

    if allowed_cores:
        cores = allowed_cores
    else:
        cores = list(range(available_cores))

    if not cores:
        cores = [0]

    print("\n" + "=" * 65)
    print(
        f"SCENARIO 2: Running {num_tasks} Processes "
        "Distributed Across Cores (Parallel)"
    )
    print(f"System Logical Cores Available: {len(cores)}")
    print("=" * 65)

    start_total = time.perf_counter()
    processes = []

    for task_id in range(num_tasks):
        assigned_core = cores[task_id % len(cores)]
        process = mp.Process(
            target=cpu_bound_workload,
            args=(task_id, assigned_core),
        )
        processes.append(process)
        process.start()

    for process in processes:
        process.join()

    total_time = time.perf_counter() - start_total
    print(
        f"--> Total Elapsed Time (Multi-Core Parallelism): "
        f"{total_time:.3f}s"
    )
    return total_time


#4
def generate_benchmark_chart(single_time: float, multi_time: float) -> None:
    """Generate and save a benchmark comparison bar chart."""
    scenarios = ["Single Core (Pinned)", "Multi-Core (Parallel)"]
    times = [single_time, multi_time]
    colors = ["#e74c3c", "#2ecc71"]

    plt.figure(figsize=(8, 5))
    bars = plt.bar(scenarios, times, color=colors, width=0.5)

    plt.ylabel("Execution Time (seconds)")
    plt.title("Activity 1: CPU Core Affinity Performance Benchmark")
    plt.grid(axis="y", linestyle="--", alpha=0.7)

    for bar in bars:
        value = bar.get_height()
        plt.text(
            bar.get_x() + bar.get_width() / 2,
            value + max(times) * 0.02,
            f"{value:.2f}s",
            ha="center",
            va="bottom",
            fontweight="bold",
        )

    plt.tight_layout()
    output_filename = "cpu_affinity_benchmark.png"
    plt.savefig(output_filename, dpi=300, bbox_inches="tight")
    plt.close()
    print(f"\n[Chart Saved]: Benchmark plot saved as '{output_filename}'")


if __name__ == "__main__":
    mp.freeze_support()

    physical_cores = psutil.cpu_count(logical=False) or 1
    logical_cores = psutil.cpu_count(logical=True) or os.cpu_count() or 1

    print("Platform CPU Hardware Configuration:")
    print(f" - Physical CPU Cores: {physical_cores}")
    print(f" - Logical CPU Cores: {logical_cores}")

    num_workers = 4  # Adjust according to host capabilities

    # Execute both scenarios
    t_single = run_single_core_contention(num_tasks=num_workers)
    t_multi = run_multi_core_parallel(num_tasks=num_workers)

    # Compute metrics
    speedup = t_single / t_multi if t_multi > 0 else 0.0

    print("\n" + "#" * 65)
    print("FINAL ACTIVITY 1 BENCHMARK SUMMARY")
    print("#" * 65)
    print(f"Single-Core Contention Time : {t_single:.3f} seconds")
    print(f"Multi-Core Parallel Time    : {t_multi:.3f} seconds")
    print(f"Overall Speedup Factor      : {speedup:.2f}x speedup")
    print("#" * 65)

    try:
        generate_benchmark_chart(t_single, t_multi)
    except Exception as error:
        print(f"Could not generate plot: {error}")
