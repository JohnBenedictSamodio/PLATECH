
import os
import time
import multiprocessing as mp
import queue

import psutil
import matplotlib.pyplot as plt


# ============================================================
# WORKER FUNCTION
# ============================================================

def cpu_bound_workload(task_id, target_core, status_queue):
    """Run a CPU-heavy workload and report messages to the parent."""

    pid = os.getpid()

    status_queue.put(
        f"[Task {task_id}] STARTED | PID: {pid} | "
        f"Requested Core: {target_core}"
    )

    # Set CPU affinity
    try:
        process = psutil.Process()
        process.cpu_affinity([target_core])
        actual_affinity = process.cpu_affinity()

        status_queue.put(
            f"[Task {task_id}] Bound Core: {target_core} | "
            f"Active Mask: {actual_affinity}"
        )

    except (AttributeError, psutil.Error, OSError) as error:
        status_queue.put(
            f"[Task {task_id}] CPU affinity error: {error}"
        )

    # CPU-heavy workload: find prime numbers
    start_time = time.perf_counter()
    count = 0

    for num in range(2, 1_000_000):
        is_prime = True
        limit = int(num ** 0.5)

        for divisor in range(2, limit + 1):
            if num % divisor == 0:
                is_prime = False
                break

        if is_prime:
            count += 1

    elapsed_time = time.perf_counter() - start_time

    status_queue.put(
        f"[Task {task_id}] COMPLETED | "
        f"Time: {elapsed_time:.3f} seconds | "
        f"Found {count} primes"
    )

    return elapsed_time


# ============================================================
# DISPLAY WORKER MESSAGES IN PYTHON IDLE
# ============================================================

def display_worker_messages(status_queue, processes):
    """Collect messages from workers and print them in the main process."""

    remaining = set(processes)

    while remaining:
        try:
            message = status_queue.get(timeout=0.2)
            print(message, flush=True)

        except queue.Empty:
            pass

        for process in list(remaining):
            if not process.is_alive():
                process.join()

                print(
                    f"[Parent] PID: {process.pid} | "
                    f"Exit Code: {process.exitcode}",
                    flush=True
                )

                remaining.remove(process)

    # Display any messages still waiting in the queue.
    while True:
        try:
            message = status_queue.get_nowait()
            print(message, flush=True)

        except queue.Empty:
            break


# ============================================================
# RUN A BENCHMARK SCENARIO
# ============================================================

def run_scenario(num_tasks, assigned_cores, scenario_name):
    print("\n" + "=" * 65, flush=True)
    print(scenario_name, flush=True)
    print("=" * 65, flush=True)

    status_queue = mp.Queue()
    processes = []

    start_total = time.perf_counter()

    # Start worker processes
    for task_id in range(num_tasks):
        process = mp.Process(
            target=cpu_bound_workload,
            args=(
                task_id,
                assigned_cores[task_id],
                status_queue
            )
        )

        processes.append(process)
        process.start()

    # Display messages while workers are running
    display_worker_messages(status_queue, processes)

    total_time = time.perf_counter() - start_total

    status_queue.close()
    status_queue.join_thread()

    print(
        f"[Parent] Total Elapsed Time: {total_time:.3f} seconds",
        flush=True
    )

    return total_time


# ============================================================
# GENERATE BENCHMARK CHART
# ============================================================

def generate_benchmark_chart(single_time, multi_time):
    scenarios = [
        "Single Core (Pinned)",
        "Multi-Core (Parallel)"
    ]

    times = [single_time, multi_time]

    plt.figure(figsize=(8, 5))

    bars = plt.bar(
        scenarios,
        times,
        width=0.5,
        color=["#e74c3c", "#2ecc71"]
    )

    plt.ylabel("Execution Time (seconds)")
    plt.title("Activity 1: CPU Core Affinity Performance Benchmark")
    plt.grid(axis="y", linestyle="--", alpha=0.7)

    for bar in bars:
        value = bar.get_height()

        plt.text(
            bar.get_x() + bar.get_width() / 2,
            value + max(times) * 0.02,
            f"{value:.2f}s",
            ha="center",
            va="bottom",
            fontweight="bold"
        )

    plt.tight_layout()

    output_filename = os.path.abspath(
        "cpu_affinity_benchmark.png"
    )

    plt.savefig(
        output_filename,
        dpi=300,
        bbox_inches="tight"
    )

    plt.close()

    print(
        f"\n[Chart Saved]: {output_filename}",
        flush=True
    )


# ============================================================
# MAIN PROGRAM
# ============================================================

def main():
    mp.freeze_support()

    physical_cores = psutil.cpu_count(logical=False) or 1
    logical_cores = psutil.cpu_count(logical=True) or os.cpu_count() or 1

    # Find CPU cores available to this program
    try:
        allowed_cores = sorted(
            psutil.Process().cpu_affinity()
        )

    except (AttributeError, psutil.Error, OSError):
        allowed_cores = list(range(logical_cores))

    if not allowed_cores:
        allowed_cores = [0]

    print("CPU HARDWARE CONFIGURATION", flush=True)
    print(f"Physical CPU Cores: {physical_cores}", flush=True)
    print(f"Logical CPU Cores: {logical_cores}", flush=True)
    print(f"Available CPU Cores: {allowed_cores}", flush=True)

    num_workers = 4

    # --------------------------------------------------------
    # SCENARIO 1: ALL WORKERS USE THE SAME CPU CORE
    # --------------------------------------------------------

    single_core = allowed_cores[0]

    single_cores = [
        single_core
    ] * num_workers

    t_single = run_scenario(
        num_workers,
        single_cores,
        f"SCENARIO 1: {num_workers} Processes "
        f"Pinned to Core {single_core} (Contention)"
    )

    # --------------------------------------------------------
    # SCENARIO 2: DISTRIBUTE WORKERS ACROSS AVAILABLE CORES
    # --------------------------------------------------------

    multi_cores = [
        allowed_cores[i % len(allowed_cores)]
        for i in range(num_workers)
    ]

    t_multi = run_scenario(
        num_workers,
        multi_cores,
        "SCENARIO 2: Workers Distributed Across CPU Cores "
        "(Parallel)"
    )

    # --------------------------------------------------------
    # CALCULATE RESULTS
    # --------------------------------------------------------

    speedup = t_single / t_multi if t_multi > 0 else 0.0

    print("\n" + "#" * 65, flush=True)
    print("FINAL ACTIVITY 1 BENCHMARK SUMMARY", flush=True)
    print("#" * 65)

    print(
        f"Single-Core Contention Time : {t_single:.3f} seconds"
    )

    print(
        f"Multi-Core Parallel Time    : {t_multi:.3f} seconds"
    )

    print(
        f"Overall Speedup Factor      : {speedup:.2f}x"
    )

    print("#" * 65, flush=True)

    # Generate the comparison graph
    try:
        generate_benchmark_chart(t_single, t_multi)

    except Exception as error:
        print(f"[Chart Error]: {error}", flush=True)


# ============================================================
# PROGRAM ENTRY POINT
# ============================================================

if __name__ == "__main__":
    mp.freeze_support()
    main()
