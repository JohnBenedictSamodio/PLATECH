import os
import time
import multiprocessing as mp

import psutil
import matplotlib.pyplot as plt


# -------------------- WORKER TASK --------------------

def cpu_bound_workload(task_id: int, target_core: int = None) -> float:
    """Run a CPU-heavy workload and optionally pin this process to one CPU core."""
    if target_core is not None:
        try:
            psutil.Process().cpu_affinity([target_core])
        except (AttributeError, psutil.Error, OSError):
            try:
                os.sched_setaffinity(0, {target_core})
            except (AttributeError, OSError):
                pass

    try:
        active_mask = psutil.Process().cpu_affinity()
    except (AttributeError, psutil.Error, OSError):
        active_mask = "unavailable"

    print(
        f"[Task {task_id}] PID: {os.getpid()} | Core Mask: {active_mask}",
        flush=True,
    )

    start = time.perf_counter()

    # CPU-intensive workload: count prime numbers below 300,000.
    prime_count = 0
    for number in range(2, 1000000):
        is_prime = True
        for divisor in range(2, int(number ** 0.5) + 1):
            if number % divisor == 0:
                is_prime = False
                break
        if is_prime:
            prime_count += 1

    elapsed = time.perf_counter() - start
    print(
        f"[Task {task_id}] Completed in {elapsed:.3f}s "
        f"(Found {prime_count} primes)",
        flush=True,
    )
    return elapsed


# -------------------- SCENARIO 1 --------------------

def run_single_core_contention(num_tasks: int = 4) -> float:
    print("\n--- SCENARIO 1: 4 Workers Pinned to Core 0 ---")
    start_total = time.perf_counter()
    processes = []

    for task_id in range(num_tasks):
        process = mp.Process(
            target=cpu_bound_workload,
            args=(task_id, 0),
        )
        processes.append(process)
        process.start()

    for process in processes:
        process.join()

    total_time = time.perf_counter() - start_total
    print(
        f"--> Total Elapsed Time (Single-Core Contention): "
        f"{total_time:.3f}s"
    )
    return total_time


# -------------------- SCENARIO 2 --------------------

def run_multi_core_parallel(num_tasks: int = 4) -> float:
    try:
        allowed_cores = sorted(psutil.Process().cpu_affinity())
    except (AttributeError, psutil.Error, OSError):
        allowed_cores = list(range(psutil.cpu_count(logical=True) or 1))

    if not allowed_cores:
        allowed_cores = [0]

    print("\n--- SCENARIO 2: 4 Workers Distributed Across Cores ---")
    start_total = time.perf_counter()
    processes = []

    for task_id in range(num_tasks):
        assigned_core = allowed_cores[task_id % len(allowed_cores)]
        process = mp.Process(
            target=cpu_bound_workload,
            args=(task_id, assigned_core),
        )
        processes.append(process)
        process.start()

    for process in processes:
        process.join()

    total_time = time.perf_counter() - start_total
    print(
        f"--> Total Elapsed Time (Multi-Core Parallelism): "
        f"{total_time:.3f}s"
    )
    return total_time


# -------------------- BENCHMARK GRAPH --------------------

def generate_benchmark_chart(single_time: float, multi_time: float) -> None:
    scenarios = ["Single Core (Pinned)", "Multi-Core (Parallel)"]
    times = [single_time, multi_time]
    bar_colors = ["#c94c55", "#36ad67"]

    fig, ax = plt.subplots(figsize=(8, 4.5))
    bars = ax.bar(scenarios, times, color=bar_colors, width=0.48)

    ax.set_ylabel("Execution Time (seconds)")
    ax.set_title("Activity 1: CPU Core Affinity Performance Benchmark")
    ax.grid(axis="y", linestyle="--", alpha=0.35)
    ax.set_axisbelow(True)

    highest = max(times) if times else 1
    ax.set_ylim(0, highest * 1.2 if highest > 0 else 1)

    for bar, value in zip(bars, times):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + highest * 0.025,
            f"{value:.2f}s",
            ha="center",
            va="bottom",
            fontweight="bold",
        )

    fig.tight_layout()
    output_filename = "cpu_affinity_benchmark.png"
    fig.savefig(output_filename, dpi=300, bbox_inches="tight")
    plt.show()
    plt.close(fig)
    print(f"\n[Chart Saved]: Benchmark plot saved as '{output_filename}'")


# -------------------- MAIN PROGRAM --------------------

if __name__ == "__main__":
    mp.freeze_support()

    physical_cores = psutil.cpu_count(logical=False) or 1
    logical_cores = psutil.cpu_count(logical=True) or os.cpu_count() or 1

    print(
        f"[System Setup] Physical Cores: {physical_cores} | "
        f"Logical Cores: {logical_cores}"
    )

    num_workers = 4

    single_time = run_single_core_contention(num_workers)
    multi_time = run_multi_core_parallel(num_workers)
    speedup = single_time / multi_time if multi_time > 0 else 0.0

    print(
        f"\n[RESULTS] Single-Core: {single_time:.2f}s | "
        f"Multi-Core: {multi_time:.2f}s | Speedup: {speedup:.2f}x"
    )

    print("\n" + "=" * 58)
    print("FINAL ACTIVITY 1 BENCHMARK SUMMARY")
    print("=" * 58)
    print(f"Single-Core Contention Time : {single_time:.3f} seconds")
    print(f"Multi-Core Parallel Time    : {multi_time:.3f} seconds")
    print(f"Overall Speedup Factor      : {speedup:.2f}x speedup")
    print("=" * 58)

    try:
        generate_benchmark_chart(single_time, multi_time)
    except Exception as error:
        print(f"Could not generate plot: {error}")
